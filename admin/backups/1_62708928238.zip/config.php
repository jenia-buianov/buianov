<?php

$database = 'buianov';
$host = 'localhost';
$user_db = 'root';
$password_db = '';
$buianov_name = 'Eugen';
$buianov_lastname = 'Buianov';
$buianov_password = 'password';
?>