<?

include("bd.php");

?>